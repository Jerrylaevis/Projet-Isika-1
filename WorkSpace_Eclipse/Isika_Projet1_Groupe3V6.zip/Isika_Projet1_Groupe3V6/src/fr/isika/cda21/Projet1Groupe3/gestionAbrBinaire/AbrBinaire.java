package fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import fr.isika.cda21.Projet1Groupe3.application.ConstantesDAppli;
import fr.isika.cda21.Projet1Groupe3.entites.Stagiaire;
import fr.isika.cda21.Projet1Groupe3.entites.StagiaireARechercher;
import fr.isika.cda21.Projet1Groupe3.outils.Outils;

public class AbrBinaire {

	Bloc racine;
	
	// ********** CONSTRUCTEURS ***********
	public AbrBinaire() {
		this.racine = null;
	}
	
	// ********** METHODES SPECIFIQUES ***********
	
	// Ajoute le bloc 'blocAAjouter' à l'arbre : détermine son index et demande à la racine de trouver sa place dans l'ABR
	public void ajouterStagiaire(Stagiaire stagAAjouter, RandomAccessFile raf) {
		
		try {
			if (this.racine==null) { 		// arbre vide -> créer racine
				this.racine = new Bloc(0, -1, stagAAjouter, -1, -1, -1);
				racine.ecrireBloc(raf);			//   ???  Peut-on et faut-il effacer le fichier ???
				//System.out.println("Ajout de la racine");	// pour debug
			}
			else {
				this.racine=this.racine.lireBlocAIndex(0, raf);		// MaJ des enfants de la racine (dommage de le faire à chaque fois, peut-on trouver mieux ?)
				int indexNouveauBloc = (int)raf.length()/ConstantesDAppli.TAILLE_BLOC;  	// détermination de l'index
				Bloc blocAAjouter = new Bloc(indexNouveauBloc, -1, stagAAjouter, -1, -1, -1);
				this.racine.ajouterBloc(blocAAjouter, raf);									// on demande au bloc racine de placer le nouveau bloc
				//System.out.println("Ajout du bloc "+stagAAjouter.getNom()+" à l'index "+indexNouveauBloc);	// pour debug
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	// Crée un ABR sous forme de fichier binaire à partir des infos du fichier .txt
	public void creerFichierBinDepuisFichierTxt(RandomAccessFile annuaireBin) {
		File annuaireTxt = new File(ConstantesDAppli.getNomFichierTxt());		// fichier à lire
		try {
			FileReader fr = new FileReader(annuaireTxt);
			BufferedReader br = new BufferedReader(fr);
			
			while(br.ready()) {
				String nom = br.readLine().toUpperCase();				// lecture des attributs du Stagiaire
				String prenom = br.readLine();
				String dep = br.readLine();
				String promo = br.readLine();
				int anneeF = Integer.parseInt(br.readLine());
				br.readLine();											// pour passer la ligne *
				
				Stagiaire nouveauStagiaire = new Stagiaire(nom, prenom, dep, promo, anneeF);    // crée le nouveau stagiaire
				this.ajouterStagiaire(nouveauStagiaire, annuaireBin);	// ajout du nouveau stagiaire à l'ABR
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste dans l'ordre alphabétique
	public List<Stagiaire> listeGND(RandomAccessFile raf) {
		if (this.racine==null) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			return this.racine.listeGND(raf, 0, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de nom égal à 'nom'
	public List<Stagiaire> rechercheNom(String nom, RandomAccessFile raf) {
		if (this.racine==null) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			return this.racine.rechercheNom(nom.toUpperCase(), raf, 0, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de nom commençant par 'nom'
	public List<Stagiaire> rechercheNomPartiel(String nom, RandomAccessFile raf) {
		if (this.racine==null) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			return this.racine.rechercheNomPartiel(nom.toUpperCase(), raf, 0, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de prénom égal à (ou commençant par) 'prenom'
	public List<Stagiaire> recherchePrenom(String prenom, RandomAccessFile raf, boolean partiel) {
		if (this.racine==null) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			return this.racine.recherchePrenom(Outils.prenomNormalise(prenom), raf, 0, new ArrayList<>(), partiel);
		}
	}
	
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de département égal à 'dep'
			public List<Stagiaire> rechercheDep(String dep, RandomAccessFile raf) {
				if (this.racine==null) {
					return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
				}
				else {
					return this.racine.rechercheDep(dep,raf, 0, new ArrayList<>());
				}
			}
	
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de promo égal à (ou commençant par) 'promo'
		public List<Stagiaire> recherchePromo(String promo, RandomAccessFile raf) {
			if (this.racine==null) {
				return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
			}
			else {
				return this.racine.recherchePromo(promo,raf, 0, new ArrayList<>());
			}
		}
		
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires d'année égale à 'annee'
		public List<Stagiaire> rechercheAnnee(int annee, RandomAccessFile raf) {
			if (this.racine==null) {
				return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
			}
			else {
					return this.racine.rechercheAnnee(annee,raf, 0, new ArrayList<>());
				}
			}	
		
	//Lance une recherche multicritère
		public List<Stagiaire> recherche(StagiaireARechercher stagiaire, RandomAccessFile raf) {
			List<Stagiaire> res = new ArrayList<>();
			boolean premiereRecherche = true;
			//recherche nom = prioritaire
			if (!(stagiaire.getNom().equals(""))) {
				if (stagiaire.isNomPartiel()) {
					res = this.rechercheNomPartiel(stagiaire.getNom().toUpperCase(), raf);		
				} else {
					res = this.rechercheNom(stagiaire.getNom().toUpperCase(), raf);
				}
			premiereRecherche = false;
			} 
			//ensuite recherche prénom - si vide on passe au prochain critère
			//on change de méthode de recherche en fonction du boolean premiereRecherche (dans l'arbre si true, dans une liste si false)
			if (!(stagiaire.getPrenom().equals(""))) {
				String prenomATester = Outils.prenomNormalise(stagiaire.getPrenom());
				if (premiereRecherche){
					res = this.recherchePrenom(prenomATester, raf, stagiaire.isPrenomPartiel());
					premiereRecherche = false;
				} else {
					res = Outils.recherchePrenomDansListe(res, prenomATester,stagiaire.isPrenomPartiel());
				}
			}
			//recherche département - si vide on passe au prochain critère
			if (!(stagiaire.getDep().equals(""))) {
				if (premiereRecherche){
					res = this.rechercheDep(stagiaire.getDep(), raf);
					premiereRecherche = false;
				} else {
					res = Outils.rechercheDepDansListe(res, stagiaire.getDep());
				}
			}
			//recherche promo - si vide on passe au prochain critère
			if (!(stagiaire.getPromo().equals(""))) {
				if (premiereRecherche){
					res = this.recherchePromo(stagiaire.getPromo().toUpperCase(), raf);
					premiereRecherche = false;
				} else {
					res = Outils.recherchePromoDansListe(res, stagiaire.getPromo());
				}
			}
			
			//recherche annee - dernier critère
			if (stagiaire.getAnneeF()>0) {
				if (premiereRecherche){
					res = this.rechercheAnnee(stagiaire.getAnneeF(), raf);
				} else {
					res = Outils.rechercheAnneeDansListe(res, stagiaire.getAnneeF());
				}
			}
		
			return res;
		}
		
	// Recherche un bloc dans l'ABR (pour suppression)
	public Bloc rechercheBloc(Stagiaire stagASupprimer,RandomAccessFile raf) {
		if (this.racine==null) {
			return null;
		}
		else {
			return this.racine.rechercheBloc(stagASupprimer, raf);
		}
	}	
		
	// Suppresssion du stagiaire 'stagASupprimer' dans l'ABR. Retourne 'false' si le stagiaire n'est pas dans l'annuaire
	public boolean supprimer(Stagiaire stagASupprimer, RandomAccessFile raf) {
		Stagiaire jerome = new Stagiaire ("POTIN", "Thomas", "75", "ATOD 21", 2014);
		Bloc bloc1 = new Bloc(0, -1, jerome, -1, -1, -1);
		System.out.println("bloc à desindexer : "+bloc1.lireBlocAIndex(0, raf));
		Bloc blocADesindexe = rechercheBloc(stagASupprimer, raf);
		System.out.println("bloc à desindexer : "+blocADesindexe);
		if (blocADesindexe==null) {
			return false;
		}
		else {
			int index = blocADesindexe.getIndex();    // infos concernant le bloc su stagiaire à supprimer
			int pere = blocADesindexe.getPere();
			int filsG = blocADesindexe.getFilsG();
			int filsD = blocADesindexe.getFilsD();
			int indexDoublon = blocADesindexe.getIndexDoublon();
			if (filsG==-1 && filsD==-1 && indexDoublon ==-1) {	// Cas 1 : je suis à la fin d'une liste de doublons
				blocADesindexe.lireBlocAIndex(pere, raf).ecrireIndexDoublon(-1, raf);  // l'indexDoublon de mon père est mis à -1
				}
			else if (indexDoublon!=-1) {						// Cas 2 : j'ai un suivant dans la liste des doublons : mon suivant va prendre ma place
				Bloc blocRemplacant = blocADesindexe.lireBlocAIndex(indexDoublon, raf); // récupération du bloc qui sera mon remplaçant dans l'ABR ou dans la liste de doublons
				blocRemplacant.setPere(pere);							// MaJ du père de mon remplaçant
				if (filsG!=-1) {										// si j'ai un filsG
					blocRemplacant.setFilsG(filsG);							// on attribue ce filsG à mon remplaçant
				}
				if (filsD!=-1) {										// si j'ai un filsD
					blocRemplacant.setFilsD(filsD);							// on attribue ce filsD à mon remplaçant
				}
				if (pere==-1) {											// si je suis la racine
					blocRemplacant.setIndex(index);							// le bloc remplaçant prend l'indice 0
					blocRemplacant.ecrireBloc(raf);							// le bloc remplaçant m'écrase dans le fichier .bin
				}
				else {													// si je ne suis pas la racine
					Bloc blocPere = blocADesindexe.lireBlocAIndex(pere, raf);// on récupère mon bloc père
					if (blocPere.getFilsG()==index) {						 // si je suis son filsG
						blocPere.ecrireFilsG(indexDoublon, raf);					// mon suivant devient son filsG
					}
					if (blocPere.getFilsD()==index) {						 // si je suis son filsD
						blocPere.ecrireFilsD(indexDoublon, raf);					// mon suivant devient son filsG
					}
					if (blocPere.getIndexDoublon()==index) {				 // si je suis son suivant dans la liste des doublons
						blocPere.ecrireIndexDoublon(indexDoublon, raf);					// mon suivant devient son suivant
					}
				}
			}
			else if (filsG==-1 && filsD==-1) {					// cas 3 : je suis une feuille (sans doublon)
				
			}
			else if (filsG==-1 || filsD==-1) {					// cas 4 : j'ai un seul fils (et pas de doublon)
				
			}
			else {												// cas 5 : j'ai deux fils (et pas de doublon)
				
			}
			return true;
		}
	}

	@Override
	public String toString() {
		if (this.racine==null) {
			return "Arbre vide";
		} else {
		return "Arbre de racine : "+this.racine.toString();
		}
	}

	
	// ********** Getters et Setters ***********
	public Bloc getRacine() {
		return racine;
	}

	public void setRacine(Bloc racine) {
		this.racine = racine;
	}
	
}
