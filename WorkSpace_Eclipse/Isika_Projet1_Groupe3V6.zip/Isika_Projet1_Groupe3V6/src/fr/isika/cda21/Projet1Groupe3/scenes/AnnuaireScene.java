package fr.isika.cda21.Projet1Groupe3.scenes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import fr.isika.cda21.Projet1Groupe3.entites.Stagiaire;
import fr.isika.cda21.Projet1Groupe3.entites.StagiaireARechercher;
import fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire.AbrBinaire;
import fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire.Bloc;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoButton;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoLabel;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoTextField;
import fr.isika.cda21.Projet1Groupe3.outils.Outils;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.print.PrinterJob;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AnnuaireScene extends Scene {

	//--------------------------------ATTRIBUTS----------------------------------------
		public BorderPane root2;
		public VBox formulaire;		
		public HBox enTete;
		public GridPane informationsStagiaire;
		public HBox boutonsBas1;
		public HBox boutonsBas2;
		public VBox listeStagiaire;
		public HBox buttons;
		public Stage stage;
		//Ajouter la liste stagiaire
		//Titres
		public Label titreFormulaire;
		public Label titreListe;
		//Labels formulaire
		public Label nom;
		public Label prenom;
		public Label departement;
		public Label promo;
		public Label anneePromo;
		public Label alertAjout; //Label qui s'affiche quand on souhaite ajouter un stagiaire mais qu'il manque des infos
		//TextFields formulaire
		public TextField textNom;
		public TextField textPrenom; 
		public TextField textPromo; 
		public TextField textAnnee; //-> rendre 4 chiffres obligatoires
		//BOUTONS
		public ChoiceBox btnDepartement;
		//public DatePicker btnDate; -> à voir ?
		public Button btnRetour;
		public Button btnRechercher;
		public Button btnAjouter;
		public Button btnImprimer;
		public Button btnSupprimer;
		public Button btnModifier;
		public Button btnEffacer; //effacer la recherche et revenir à la liste initiale
		//Liste observable
		public ObservableList<Stagiaire> observableList;
		public TableView<Stagiaire> table;
		
		//--------------------------------CONSTRUCTEUR----------------------------------------
		
		public AnnuaireScene(Stage stage, AbrBinaire arbre, RandomAccessFile raf) { //Arbre et raf nécessaires pour la construction du tableView
		super(new BorderPane(),1200,750);

		titreFormulaire = new Label ("FORMULAIRE");
		
		//PARTIE GAUCHE = FORMULAIRE
		alertAjout = new Label();
		formulaire = new VBox();
		enTete = new HBox();
		informationsStagiaire = new GridPane();
		formulaire.setPadding(new Insets(0,50,0,0));
		  informationsStagiaire.setHgap(10);
		  informationsStagiaire.setVgap(10);
		  informationsStagiaire.setPadding(new Insets(10, 30, 10, 10));
		boutonsBas1 = new HBox();
		boutonsBas2 = new HBox();
		boutonsBas1.setPadding(new Insets(20));
		boutonsBas2.setPadding(new Insets(20));
		boutonsBas1.setSpacing(10);
		boutonsBas2.setSpacing(10);
		
//		public TextField textNom;
//		public TextField textPrenom; 
//		public TextField textPromo; 
		
		//1ere ligne : BTNRETOUR/TITRE
		btnRetour = new PersoButton("Retour");
		enTete.getChildren().addAll(btnRetour); // Ajouter un log
		
		//ACTION BTNRETOUR -> LOGINSCENE
		
		btnRetour.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				stage.setScene(new LoginScene(stage,arbre,raf));
			}
		});

		//GridPane NOM , PRENOM 
		Label titreFormulaire = new Label("FORMULAIRE ");
		titreFormulaire.setStyle("-fx-text-fill: white");
		nom = new PersoLabel ("Nom :");
		
		textNom = new PersoTextField();
		prenom = new PersoLabel ("Prénom :");
	
		textPrenom = new PersoTextField();
		informationsStagiaire.addRow(0,titreFormulaire);
		informationsStagiaire.addRow(1,nom , textNom);
		informationsStagiaire.addRow(2,prenom , textPrenom);
		informationsStagiaire.setValignment(prenom,VPos.BASELINE);
		//formulaire.addRow(1, nom,textNom, prenom, textPrenom);
		
		//3eme ligne : DEPARTEMENT
		departement = new PersoLabel ("Département :");
		
		btnDepartement = new ChoiceBox<String>();
		btnDepartement.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
		listerDep(); //lecture du fichier txt et remplissage de la choice box	
		informationsStagiaire.addRow(3,departement ,btnDepartement);
		//formulaire.addRow(2, departement, btnDepartement);
		
		//4eme ligne : PROMO + ANNEE
		promo = new PersoLabel ("Promotion : ");
		
		textPromo = new PersoTextField();
		anneePromo = new PersoLabel ("Année :");
		
		textAnnee = new PersoTextField();
		informationsStagiaire.addRow(4,promo ,textPromo );
		informationsStagiaire.addRow(5,anneePromo, textAnnee);
		
		//formulaire.addRow(3, promo, textPromo, anneePromo, textAnnee);
		
		//HBoxs
		btnRechercher = new PersoButton("Rechercher");
		btnAjouter = new PersoButton("Ajouter");
		btnEffacer = new PersoButton("Effacer la recherche");
		btnSupprimer = new PersoButton ("Supprimer");
		btnModifier = new PersoButton ("Modifier");
		//formulaire.addRow(4, btnRechercher, btnAjouter);
		alertAjout = new PersoLabel("");
		informationsStagiaire.addRow(6, alertAjout);
		boutonsBas1.getChildren().addAll(btnRechercher,btnAjouter,btnEffacer);
		boutonsBas2.getChildren().addAll(btnModifier,btnSupprimer);
		
		root2 = ((BorderPane)this.getRoot());
		root2.setLeft(formulaire);
		root2.setPadding(new Insets(10,10,10,10));
		root2.setStyle("-fx-background-color:#24475B");
//		formulaire.setVgap(10);
//		root2.setHgap(10);

		
		formulaire.getChildren().addAll(enTete,informationsStagiaire,boutonsBas1,boutonsBas2);
	
		//formulaire.addRow(5,btnEffacer);
		
		//7ème ligne : LABEL ALERTE
		//formulaire.addRow(6, alertAjout);
		
		//ACTIONS BTN AJOUTER ET RECHERCHER
		btnAjouter.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {	
				ajouterStagiaireViaFormulaire(arbre, raf);
			}
		});

		btnRechercher.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				rechercher(arbre, raf);
			}
		});
		//ACTIONS BTN EFFACER
		btnEffacer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				effacerRecherche(arbre,raf);
			}
		});
		
		//PARTIE DROITE = TABLEVIEW
		listeStagiaire = new VBox();
		listeStagiaire.setSpacing(10);
		titreListe = new Label ("LISTE DES STAGIAIRES");
		titreListe.setStyle("-fx-text-fill: white");
		observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
		creerTableView(arbre,raf);
		
		//BOUTONS IMPRIMER SUPPRIMER MODIFIER
		buttons = new HBox();
		buttons.setPadding(new Insets(10,0,0,0));
		buttons.setAlignment(Pos.BASELINE_RIGHT);
		
		btnImprimer = new PersoButton("Imprimer");
		
	
		// Action sur le bouton Imprimer ----------------> MANQUE FORMAT POUR VOIR LE TABLEAU EN ENTIER SUR LE PDF
		btnImprimer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				// Creation du printer job
				PrinterJob job = PrinterJob.createPrinterJob();
				// Montre la boite de dialogue
				boolean proceed = job.showPrintDialog(stage);
				// Si l'utilisateur clique sur imprimer dans la boite de dialogue
				if (proceed) {
					job.jobStatusProperty().addListener((observable, oldValue, newValue) -> {
					});
					// Imprime la zone texte
					boolean printed = job.printPage(table);
					if (printed) {
						job.endJob();
					}
				}
			}
		}); // fin action sur le bouton imprimer
		
		
		
		//Action sur les boutons supprimer et modifier
		btnSupprimer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {	
				alerteSupprimer();
			}
		});
		btnModifier.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				alerteModifier();
			}
		});
		
		buttons.getChildren().addAll(btnImprimer);
		
		//AFFICHAGE ou MASQUAGE DES BOUTONS SUPP et MOD
		affichageAdmin(); 
		
		listeStagiaire.getChildren().addAll(titreListe, table, buttons);
		listeStagiaire.setPadding(new Insets(0,20,0,0));
		listeStagiaire.setPrefWidth(1000);
		root2.setCenter(listeStagiaire);
		
	}
		
	//------------------------------------------------METHODES-----------------------------------------------------------
		
		//permet de passer l'AnnuaireScene en mode admin
		public void affichageAdmin() {
			//si le user clique sur Acceder -> isAdmin = faux et les btn supprimer et modifier sont invisibles
			//si le user clique sur Valider -> isAdmin = vrai et les btn sont visibles
			if (LoginScene.isAdmin == false) {
				//table n'est pas éditable en mode visiteur
				btnSupprimer.setVisible(false);
				btnModifier.setVisible(false);
			}
		}
		
		//liste des départements = on va lire les dép dans le fichier txt et les ajouter dans une liste, puis on ajoute chaque élément un par un à la choice box
		public void listerDep() {
			try {
				FileReader fr = new FileReader("src/mesFichiers/departements.txt");
				BufferedReader br = new BufferedReader(fr);
				
				while(br.ready()) { //chaque ligne lue = new département qu'on ajoute à la liste
					String departement = br.readLine();
					btnDepartement.getItems().add(departement);
				}
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//ajouter un stagiaire au clic
		//si les champs ne sont pas remplis = border rouge sur les textsFields et label d'erreur(alertAjout.setText)
		//ajoute un nouveau stagiaire si tout est ok -> label de confirmation(alertAjout.setText)
		public void ajouterStagiaireViaFormulaire(AbrBinaire arbre, RandomAccessFile raf) {
			if ((textNom.getText().equals("")) || (textPrenom.getText().equals("")) || (textPromo.getText().equals("")) || (textAnnee.getText().equals("")) || (btnDepartement.getValue()==null)) {
				alertAjout.setText("Veuillez remplir tous les champs !");
				alertAjout.setStyle("-fx-text-fill : red");
				if(textNom.getText()=="") {
					textNom.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textPrenom.getText().equals("")) {
					textPrenom.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textPromo.getText().equals("")) {
					textPromo.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textAnnee.getText().equals("")) {
					textAnnee.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (btnDepartement.getValue()==null) {
					btnDepartement.setStyle("-fx-border-color: red");
				}
			} else {
				//faire l'ajout d'un stagiaire
				Stagiaire nouveauStagiaire = new Stagiaire(textNom.getText().toUpperCase(),textPrenom.getText(),((String)(btnDepartement.getValue())).substring(0,2),textPromo.getText(),Integer.parseInt(textAnnee.getText()));
				arbre.ajouterStagiaire(nouveauStagiaire,raf);
				//on met à jour le tableView
				creerTableView(arbre,raf);
				//on met à jour la scène
				listeStagiaire.getChildren().set(1, table);
								
				//puis écrire :
				alertAjout.setText("Le stagiaire " + textNom.getText()+ " " + textPrenom.getText() + " " + "a bien été ajouté à l'annuaire.");
				//et mettre en forme
				alertAjout.setStyle("-fx-text-fill : green");
				textNom.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
				textNom.clear();
				textPrenom.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
				textPrenom.clear();
				textPromo.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
				textPromo.clear();
				textAnnee.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
				textAnnee.clear();
				btnDepartement.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
				btnDepartement.setValue(null);
				}
			}
		
		//méthode pour afficher notre liste de stagiaire dans le table view
		public void creerTableView(AbrBinaire arbre, RandomAccessFile raf) {			
			table = new TableView<>(observableList);
			table.setEditable(true);
			//on crée les colonnes
			TableColumn <Stagiaire, String> colNom = new TableColumn<>("Nom");
			colNom.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("nom"));
			//colNom.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colPrenom = new TableColumn<>("Prénom");
			colPrenom.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("prenom"));
			//colPrenom.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colDep = new TableColumn<>("Département");
			colDep.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("dep"));
			//colDep.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colPromo = new TableColumn<>("Promotion");
			colPromo.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("promo"));
			//colPromo.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colAnnee = new TableColumn<>("Année");
			colAnnee.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("anneeF"));
			//colAnnee.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			
			table.getColumns().addAll(colNom,colPrenom,colDep,colPromo,colAnnee); //ajout des colonnes dans la table
			table.setColumnResizePolicy(table.CONSTRAINED_RESIZE_POLICY);
			table.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
			table.setPrefSize(500, 650);
		}
		
		//Fenêtres d'alerte pour la suppression d'un stagiaire
		//les fenêtres d'alerte gèrent directement le lancement des actions lorsqu'on clique sur OK, et ferment la fenêtre dans les 2 cas (OK ou CANCEL)
		public void alerteSupprimer() {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Supprimer ?");
			alert.setHeaderText("Etes-vous sûr de vouloir supprimer le stagiaire ?");
			
			Optional<ButtonType> option = alert.showAndWait();
			
			if (option.get()==ButtonType.OK) {
				//lancer la méthode supprimer
				supprimerUnStagiaire(null, null);
			}
		}
		
		//méthode pour le bouton supprimer  (Ajouter la méthode supprimer un stagiaire de l'arbre) ????????
		public void supprimerUnStagiaire(AbrBinaire arbre, RandomAccessFile raf) {
		    int selectedIndex = table.getSelectionModel().getSelectedIndex();
		    table.getItems().remove(selectedIndex);
		}
		
		//Fenêtres d'alerte pour la modification d'un stagiaire
		public void alerteModifier() {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Modifier ?");
			alert.setHeaderText("Etes-vous sûr de vouloir modifier le stagiaire ?");
			
			Optional<ButtonType> option = alert.showAndWait();
			
			if (option.get()==ButtonType.OK) {
				
				//lancer la méthode modifier
			}
		}
		
		//méthode de recherche simple + multiple à partir des entrées du user
		public void rechercher(AbrBinaire arbre, RandomAccessFile raf) {
			//on crée notre stagiaire à rechercher en récupérant les infos entrées dans le formulaire
			//le stagiaire a recherché est composé du : nom, prenom, dep, promo, anneeF, nomPartiel, prenomPartiel
			StagiaireARechercher leStagiaire = new StagiaireARechercher();
			leStagiaire.setNom(textNom.getText());
			leStagiaire.setPrenom(textPrenom.getText());
			//condition sur la choice box car sinon retourne erreur "getValue=null"
			if ((String)(btnDepartement.getValue())==null) {
				leStagiaire.setDep("");
			} else {
				leStagiaire.setDep(((String)(btnDepartement.getValue())).substring(0,2));
			}
			leStagiaire.setPromo(textPromo.getText());
			//idem, condition sur l'année car sinon retourne erreur 
			if (textAnnee.getText().equals("")) {
				leStagiaire.setAnneeF(0);
			} else {
				leStagiaire.setAnneeF(Integer.parseInt(textAnnee.getText()));
			}
			leStagiaire.setNomPartiel(true);
			leStagiaire.setPrenomPartiel(true);
			
			//System.out.println(arbre.recherche(leStagiaire, raf));		//affichage en console
			//on met à jour notre table avec résultat de la recherche
			observableList = FXCollections.observableArrayList(arbre.recherche(leStagiaire, raf));
			creerTableView(arbre,raf);
			listeStagiaire.getChildren().set(1, table);
		}
		
		//clear tous les champs après une recherche et remettre la table initiale 
		public void effacerRecherche(AbrBinaire arbre, RandomAccessFile raf) {
			textNom.clear();
			textPrenom.clear();
			btnDepartement.setValue(null);
			textPromo.clear();
			textAnnee.clear();
			observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
			creerTableView(arbre,raf);
			listeStagiaire.getChildren().set(1, table);
		}
		
		
}