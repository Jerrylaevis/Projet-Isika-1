package fr.isika.cda21.Projet1Groupe3.scenes;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Optional;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfDocument;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import fr.isika.cda21.Projet1Groupe3.application.ConstantesDAppli;
import fr.isika.cda21.Projet1Groupe3.entites.Stagiaire;
import fr.isika.cda21.Projet1Groupe3.entites.StagiaireARechercher;
import fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire.AbrBinaire;
import fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire.Bloc;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoButton;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoLabel;
import fr.isika.cda21.Projet1Groupe3.objetsGraphiques.PersoTextField;
import fr.isika.cda21.Projet1Groupe3.outils.Outils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.print.PrinterJob;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class AnnuaireScene extends Scene {

	//--------------------------------ATTRIBUTS----------------------------------------
		public BorderPane root2;
		public VBox formulaire;		
		public HBox enTete;
		public GridPane informationsStagiaire;
		public HBox boutonsBas1;
		public HBox boutonsBas2;
		public HBox footer;
		public VBox listeStagiaire;
		public HBox buttons;
		public HBox alerte;
		public Stage stage;
		//Titres
		public Label titreFormulaire;
		public Label titreListe;
		//Labels formulaire
		public Label nom;
		public Label prenom;
		public Label departement;
		public Label promo;
		public Label anneePromo;
		public Label messageAlerte; //Label qui s'affiche pour confirmer une action btn ou indiquer une erreur
		//TextFields formulaire
		public TextField textNom;
		public TextField textPrenom; 
		public TextField textPromo; 
		public TextField textAnnee; //-> rendre 4 chiffres obligatoires
		//BOUTONS
		public ChoiceBox btnDepartement;
		public Button btnRetour;
		public Button btnRechercher;
		public Button btnAjouter;
		public Button btnImprimer;
		public Button btnSupprimer;
		public Button btnModifier;
		public Button btnEffacer; //effacer la recherche et revenir à la liste initiale
		public Button btnAide;
		//Liste observable
		public ObservableList<Stagiaire> observableList;
		public TableView<Stagiaire> table;
		
		//--------------------------------CONSTRUCTEUR----------------------------------------
		
		public AnnuaireScene(Stage stage, AbrBinaire arbre, RandomAccessFile raf) { //Arbre et raf nécessaires pour la construction du tableView
		super(new BorderPane(),1200,750);
		
		//PARTIE GAUCHE = FORMULAIRE
		messageAlerte = new Label();
		formulaire = new VBox();
		alerte = new HBox();
		informationsStagiaire = new GridPane();
		informationsStagiaire.setHgap(10);
		informationsStagiaire.setVgap(20);
		informationsStagiaire.setPadding(new Insets(30, 30, 10, 10));
		boutonsBas1 = new HBox();
		boutonsBas2 = new HBox();
		boutonsBas1.setPadding(new Insets(20));
		boutonsBas2.setPadding(new Insets(20));
		boutonsBas1.setSpacing(10);
		boutonsBas2.setSpacing(10);
		
		//BTNRETOUR/TITRE
		titreFormulaire = new Label ("FORMULAIRE");
		titreFormulaire.setFont(Font.font("Verdana",FontWeight.BOLD,14));
		titreFormulaire.setStyle("-fx-text-fill: white");
		titreFormulaire.setPadding(new Insets(5,0,-20,30));

		//GridPane : NOM, PRENOM 
		nom = new PersoLabel ("Nom :");
		textNom = new PersoTextField();
		textNom.setPromptText("ex : DUPONT ou DU*");
		prenom = new PersoLabel ("Prénom :");
		textPrenom = new PersoTextField();
		textPrenom.setPromptText("ex : Joachim ou joa*");
		informationsStagiaire.addRow(1,nom , textNom);
		informationsStagiaire.addRow(2,prenom , textPrenom);
		informationsStagiaire.setValignment(prenom,VPos.BASELINE);
		
		//DEPARTEMENT
		departement = new PersoLabel ("Département :");
		btnDepartement = new ChoiceBox<String>();
		btnDepartement.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
		listerDep(); //lecture du fichier txt et remplissage de la choice box	
		informationsStagiaire.addRow(3,departement ,btnDepartement);

		//PROMO + ANNEE
		promo = new PersoLabel ("Promotion : ");
		textPromo = new PersoTextField();
		anneePromo = new PersoLabel ("Année :");
		textAnnee = new PersoTextField();
		informationsStagiaire.addRow(4,promo ,textPromo );
		informationsStagiaire.addRow(5,anneePromo, textAnnee);
		
		//BUTTONS + LABEL MESSAGEALERTE
		btnRechercher = new PersoButton("Rechercher");
		btnAjouter = new PersoButton("Ajouter");
		btnEffacer = new PersoButton("Effacer");
		btnSupprimer = new PersoButton ("Supprimer");
		btnModifier = new PersoButton ("Modifier");
		messageAlerte = new PersoLabel("");
		alerte.getChildren().addAll(messageAlerte);
		alerte.setPadding(new Insets(0,0,0,10));
		boutonsBas1.getChildren().addAll(btnRechercher,btnEffacer,btnAjouter);
		boutonsBas2.getChildren().addAll(btnModifier,btnSupprimer);
		
		//BTN RETOUR ET AIDE -> FOOTER
		footer = new HBox();
		Image imageBtnRetour = new Image("btnretour.png");
		ImageView imageView = new ImageView(imageBtnRetour);
		btnRetour = new Button("",imageView);

		btnAide = new PersoButton("Aide");
		Image imageBtnAide = new Image("btnaide.png");
		ImageView imageView2 = new ImageView(imageBtnAide);
		btnAide = new Button("",imageView2);
		footer.getChildren().addAll(btnRetour,btnAide);
		footer.setSpacing(320);
		footer.setPadding(new Insets(120,0,0,20));

		//ACTION BTNRETOUR -> vers LOGINSCENE
		btnRetour.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				stage.setScene(new LoginScene(stage,arbre,raf));
			}
		});
		
		//ACTIONS BTN AJOUTER RECHERCHER EFFACER
		btnAjouter.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {	
				ajouterStagiaireViaFormulaire(arbre, raf);
			}
		});

		btnRechercher.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				rechercher(arbre, raf);
			}
		});
		
		btnEffacer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				effacer(arbre,raf);
			}
		});
		
		//PLACEMENT DANS LA BORDERPANE
		root2 = ((BorderPane)this.getRoot());
		root2.setLeft(formulaire);
		root2.setPadding(new Insets(10,20,20,20));
		formulaire.getChildren().addAll(titreFormulaire,informationsStagiaire,alerte,boutonsBas1,boutonsBas2,footer);
		formulaire.setAlignment(Pos.CENTER);
		formulaire.setPadding(new Insets(0,20,-150,0));

		//PARTIE DROITE = TABLEVIEW
		listeStagiaire = new VBox();
		listeStagiaire.setSpacing(10);
		titreListe = new Label ("LISTE DES STAGIAIRES");
		titreListe.setFont(Font.font("Verdana",FontWeight.BOLD,14));
		titreListe.setPadding(new Insets(20,0,5,230));
		titreListe.setStyle("-fx-text-fill: white");
		observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
		creerTableView(arbre,raf);
		afficherStagiaireFormulaire ();

		//BOUTONS IMPRIMER SUPPRIMER MODIFIER
		buttons = new HBox();
		buttons.setPadding(new Insets(5,0,0,0));
		buttons.setAlignment(Pos.BASELINE_RIGHT);
		
		//btnImprimer = new PersoButton("Imprimer");
		Image imageBtnImprimer = new Image("btnimprimer.png");
		ImageView imageView3 = new ImageView(imageBtnImprimer);
		btnImprimer = new Button("",imageView3);

		// Action sur le bouton Imprimer ----------------> MANQUE FORMAT POUR VOIR LE TABLEAU EN ENTIER SUR LE PDF
		btnImprimer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				//Creation du printer job
//				PrinterJob job = PrinterJob.createPrinterJob();
//				// Montre la boite de dialogue
//				boolean proceed = job.showPrintDialog(stage);
//				// Si l'utilisateur clique sur imprimer dans la boite de dialogue			
//				if (proceed) {
//					job.jobStatusProperty().addListener((observable, oldValue, newValue) -> {
//					});
//					// Imprime la zone texte
//					boolean printed = job.printPage(table);
//					if (printed) {
//						job.endJob();
//					}
//				}
			}		
		}); 

		//Action sur les boutons supprimer et modifier
		btnSupprimer.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {	
			if ((textNom.getText().equals("")) || (textPrenom.getText().equals("")) || (textPromo.getText().equals("")) || (textAnnee.getText().equals("")) || (btnDepartement.getValue()==null)) {
				messageAlerte.setText("Il n'y a personne à supprimer !");
				messageAlerte.setStyle("-fx-text-fill : red");
			} else {
				supprimer(arbre, raf);
			}
			}
		});
		
		btnModifier.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent args) {
				if ((textNom.getText().equals("")) || (textPrenom.getText().equals("")) || (textPromo.getText().equals("")) || (textAnnee.getText().equals("")) || (btnDepartement.getValue()==null)) {
					messageAlerte.setText("Il n'y a personne à modifier !");
					messageAlerte.setStyle("-fx-text-fill : red");
				} else {
					modifier(arbre, raf);
				}
			}
		});
		
		buttons.getChildren().addAll(btnImprimer);
		
		//AFFICHAGE ou MASQUAGE DES BOUTONS SUPP et MOD
		affichageAdmin(); 
		
		//PLACEMENT DANS LA BORDERPANE
		listeStagiaire.getChildren().addAll(titreListe, table, buttons);
		listeStagiaire.setPadding(new Insets(0,20,0,20));
		listeStagiaire.setPrefWidth(1000);
		root2.setCenter(listeStagiaire);
		//root2.setStyle("-fx-background-color:#24475B");
		
		Image image = new Image("Fond_Annuaire.png");
		BackgroundImage imgBack = new BackgroundImage(image,BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,BackgroundPosition.DEFAULT,BackgroundSize.DEFAULT);
		Background background = new Background(imgBack);
		root2.setBackground(background);

	}
		
	//------------------------------------------------METHODES-----------------------------------------------------------

		//permet de passer l'AnnuaireScene en mode admin
		public void affichageAdmin() {
			//si le user clique sur Acceder -> isAdmin = faux et les btn supprimer et modifier sont invisibles
			//si le user clique sur Valider -> isAdmin = vrai et les btn sont visibles
			if (LoginScene.isAdmin == false) {
				//table n'est pas éditable en mode visiteur
				btnSupprimer.setVisible(false);
				btnModifier.setVisible(false);
			}
		}
		
		//liste des départements = on va lire les dép dans le fichier txt et les ajouter dans une liste, puis on ajoute chaque élément un par un à la choice box
		public void listerDep() {
			try {
				FileReader fr = new FileReader("src/mesFichiers/departements.txt");
				BufferedReader br = new BufferedReader(fr);
				
				while(br.ready()) { //chaque ligne lue = new département qu'on ajoute à la liste
					String departement = br.readLine();
					btnDepartement.getItems().add(departement);
				}
				br.close();
				fr.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		//ajouter un stagiaire au clic
		//si les champs ne sont pas remplis = border rouge sur les textsFields et label d'erreur(alertAjout.setText)
		//ajoute un nouveau stagiaire si tout est ok -> label de confirmation(alertAjout.setText)
		public void ajouterStagiaireViaFormulaire(AbrBinaire arbre, RandomAccessFile raf) {
			if ((textNom.getText().equals("")) || (textPrenom.getText().equals("")) || (textPromo.getText().equals("")) || (textAnnee.getText().equals("")) || (btnDepartement.getValue()==null)) {
				messageAlerte.setText("Veuillez remplir tous les champs !");
				messageAlerte.setStyle("-fx-text-fill : red");
				if(textNom.getText()=="") {
					textNom.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textPrenom.getText().equals("")) {
					textPrenom.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textPromo.getText().equals("")) {
					textPromo.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (textAnnee.getText().equals("")) {
					textAnnee.setStyle("-fx-text-box-border: red; -fx-focus-color: red");
				}
				if (btnDepartement.getValue()==null) {
					btnDepartement.setStyle("-fx-border-color: red;-fx-focus-color: red");
				}
			} else {
				//faire l'ajout d'un stagiaire
				Stagiaire nouveauStagiaire = new Stagiaire(textNom.getText().toUpperCase(),textPrenom.getText(),((String)(btnDepartement.getValue())).substring(0,2),textPromo.getText(),Integer.parseInt(textAnnee.getText()));
				if (arbre.ajouterStagiaire(nouveauStagiaire,raf) == true) {
					//on met à jour le tableView
					observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
					creerTableView(arbre,raf);
					//on met à jour la scène
					listeStagiaire.getChildren().set(1, table);			
					//puis écrire :
					messageAlerte.setText("Le stagiaire " + textNom.getText()+ " " + textPrenom.getText() + " " + "a bien été ajouté.");
					//et mettre en forme
					messageAlerte.setStyle("-fx-text-fill :  lightgreen");
					textNom.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
					textNom.clear();
					textPrenom.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
					textPrenom.clear();
					textPromo.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
					textPromo.clear();
					textAnnee.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
					textAnnee.clear();
					btnDepartement.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
					btnDepartement.setValue(null);
				} else {
					messageAlerte.setText("Ce stagiaire existe déjà.");
					messageAlerte.setStyle("-fx-text-fill :  red");
				}
			}
			afficherStagiaireFormulaire ();
			} 
		
		//méthode pour afficher notre liste de stagiaire dans le table view
		public void creerTableView(AbrBinaire arbre, RandomAccessFile raf) {			
			table = new TableView<>(observableList);
			table.setEditable(true);
			//on crée les colonnes
			TableColumn <Stagiaire, String> colNom = new TableColumn<>("Nom");
			colNom.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("nom"));
			//colNom.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colPrenom = new TableColumn<>("Prénom");
			colPrenom.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("prenom"));
			//colPrenom.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colDep = new TableColumn<>("Département");
			colDep.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("dep"));
			//colDep.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colPromo = new TableColumn<>("Promotion");
			colPromo.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("promo"));
			//colPromo.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			TableColumn <Stagiaire, String> colAnnee = new TableColumn<>("Année");
			colAnnee.setCellValueFactory(new PropertyValueFactory<Stagiaire, String>("anneeF"));
			//colAnnee.setCellFactory(TextFieldTableCell.<Stagiaire> forTableColumn()); //Pour rendre la cellule du Nom modifiable
			
			table.getColumns().addAll(colNom,colPrenom,colDep,colPromo,colAnnee); //ajout des colonnes dans la table
			table.setColumnResizePolicy(table.CONSTRAINED_RESIZE_POLICY);
			table.setStyle("-fx-focus-color: orange; -fx-faint-focus-color: transparent");
			table.setPrefSize(500, 650);
		}
		
		//Fenêtres d'alerte pour la suppression d'un stagiaire
		//les fenêtres d'alerte gèrent directement le lancement des actions lorsqu'on clique sur OK, et ferment la fenêtre dans les 2 cas (OK ou CANCEL)
		//idem pour la modification
		public void supprimer(AbrBinaire arbre, RandomAccessFile raf) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Supprimer ?");
			alert.setHeaderText("Etes-vous sûr de vouloir supprimer ce stagiaire ?");
			
			Optional<ButtonType> option = alert.showAndWait();
			
			if (option.get()==ButtonType.OK) {
				//lancer la méthode supprimer
			    Stagiaire stagiaireFormulaire = table.getSelectionModel().getSelectedItem();
			    System.out.println(stagiaireFormulaire);
		        if (arbre.supprimer(stagiaireFormulaire,raf) == true) {
		            messageAlerte.setText("Le stagiaire a été supprimé.");
		            messageAlerte.setStyle("-fx-text-fill :  lightgreen");
		        } else {
		            messageAlerte.setText("Ce stagiaire n'est pas dans l'annuaire.");
		            messageAlerte.setStyle("-fx-text-fill : red");
		        }
		        observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
				creerTableView(arbre,raf);
				listeStagiaire.getChildren().set(1, table);
				textNom.clear();
				textPrenom.clear();
				btnDepartement.setValue(null);
				textPromo.clear();
				textAnnee.clear();
				afficherStagiaireFormulaire();
				//Outils.afficherListe(arbre.listeGND(raf));
				try {
					for (int i=0; i<raf.length()/ConstantesDAppli.TAILLE_BLOC; i++) {
						System.out.println(Bloc.lireBlocAIndex(i, raf));
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		//Fenêtres d'alerte pour la modification d'un stagiaire
		public void modifier(AbrBinaire arbre, RandomAccessFile raf) {
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Modifier ?");
			alert.setHeaderText("Etes-vous sûr de vouloir modifier ce stagiaire ?");
		
			Optional<ButtonType> option = alert.showAndWait();
			
			if (option.get()==ButtonType.OK) {
					//lancer la méthode modifier
				Stagiaire stagiaire = table.getSelectionModel().getSelectedItem();
			    System.out.println(stagiaire);
				Stagiaire stagiaireModifie = new Stagiaire(textNom.getText().toUpperCase(),textPrenom.getText(),((String)(btnDepartement.getValue())).substring(0,2),textPromo.getText(),Integer.parseInt(textAnnee.getText()));
				    if (arbre.modifier(stagiaire, stagiaireModifie, raf) == true) {
				    	messageAlerte.setText("Le stagiaire a bien été modifié.");
				    	 messageAlerte.setStyle("-fx-text-fill :  lightgreen");
				    } else {
				    	messageAlerte.setText("Il n'y a aucune modification à apporter.");
				    	messageAlerte.setStyle("-fx-text-fill : red");
				    }
			        observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
					creerTableView(arbre,raf);
					listeStagiaire.getChildren().set(1, table);
					textNom.clear();
					textPrenom.clear();
					btnDepartement.setValue(null);
					textPromo.clear();
					textAnnee.clear();
					afficherStagiaireFormulaire();
					try {
						for (int i=0; i<raf.length()/ConstantesDAppli.TAILLE_BLOC; i++) {
							System.out.println(Bloc.lireBlocAIndex(i, raf));
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		
		//méthode de recherche simple + multiple à partir des entrées du user
		public void rechercher(AbrBinaire arbre, RandomAccessFile raf) {
			//on crée notre stagiaire à rechercher en récupérant les infos entrées dans le formulaire
			//le stagiaire a recherché est composé du : nom, prenom, dep, promo, anneeF, nomPartiel, prenomPartiel
			StagiaireARechercher leStagiaire = new StagiaireARechercher();
			String nom = textNom.getText();
			String prenom = textPrenom.getText();
			if (!nom.equals("") && nom.substring(nom.length()-1).equals("*")) {
				leStagiaire.setNomPartiel(true);
				nom = nom.substring(0,nom.length()-1);
			} else {
				leStagiaire.setNomPartiel(false);
			}
			leStagiaire.setNom(nom);
			if (!prenom.equals("") && prenom.substring(prenom.length()-1).equals("*")) {
				leStagiaire.setPrenomPartiel(true);
				prenom = prenom.substring(0,prenom.length()-1);
			} else {
				leStagiaire.setPrenomPartiel(false);
			}
			leStagiaire.setPrenom(prenom);
			//condition sur la choice box car sinon retourne erreur "getValue=null"
			if ((String)(btnDepartement.getValue())==null) {
				leStagiaire.setDep("");
			} else {
				leStagiaire.setDep(((String)(btnDepartement.getValue())).substring(0,2));
			}
			leStagiaire.setPromo(textPromo.getText());
			//idem, condition sur l'année car sinon retourne erreur 
			if (textAnnee.getText().equals("")) {
				leStagiaire.setAnneeF(0);
			} else {
				leStagiaire.setAnneeF(Integer.parseInt(textAnnee.getText()));
			}
			//System.out.println(arbre.recherche(leStagiaire, raf));		//affichage en console
			//on met à jour notre table avec résultat de la recherche
			observableList = FXCollections.observableArrayList(arbre.recherche(leStagiaire, raf));
			creerTableView(arbre,raf);
			listeStagiaire.getChildren().set(1, table);
			afficherStagiaireFormulaire ();
		}
		
		//clear tous les champs et remettre la table initiale 
		public void effacer(AbrBinaire arbre, RandomAccessFile raf) {
			textNom.clear();
			textPrenom.clear();
			btnDepartement.setValue(null);
			textPromo.clear();
			textAnnee.clear();
			observableList = FXCollections.observableArrayList(arbre.listeGND(raf));
			creerTableView(arbre,raf);
			listeStagiaire.getChildren().set(1, table);
			messageAlerte.setText("");
			afficherStagiaireFormulaire ();
		}
		
		//Methode pour afficher les informations d'un stagiaire existant dans la liste dans le formulaire
		public void afficherStagiaireFormulaire () {	
			table.getSelectionModel().selectedItemProperty().addListener((v, oldValue, newValue) -> {
	            textNom.setText(newValue.getNom());
	            textPrenom.setText(newValue.getPrenom());
	            btnDepartement.setValue(newValue.getDep());
	            textPromo.setText(newValue.getPromo());
	            textAnnee.setText(Integer.toString(newValue.getAnneeF()));
	            messageAlerte.setText("");
			});
		}
		
		
}