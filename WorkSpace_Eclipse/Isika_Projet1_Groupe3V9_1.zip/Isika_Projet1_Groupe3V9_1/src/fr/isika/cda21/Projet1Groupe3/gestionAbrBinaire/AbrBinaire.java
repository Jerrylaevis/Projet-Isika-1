package fr.isika.cda21.Projet1Groupe3.gestionAbrBinaire;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

import fr.isika.cda21.Projet1Groupe3.application.ConstantesDAppli;
import fr.isika.cda21.Projet1Groupe3.entites.Stagiaire;
import fr.isika.cda21.Projet1Groupe3.entites.StagiaireARechercher;
import fr.isika.cda21.Projet1Groupe3.outils.Outils;

public class AbrBinaire {

	int racine;
	
	// ********** CONSTRUCTEURS ***********
	public AbrBinaire() {
		this.racine = -1;
	}
	
	// ********** METHODES SPECIFIQUES ***********
	
	// Ajoute le bloc 'blocAAjouter' à l'arbre : détermine son index et demande à la racine de trouver sa place dans l'ABR
	public boolean ajouterStagiaire(Stagiaire stagAAjouter, RandomAccessFile raf) {
		
		try {
			if (this.racine==-1) { 		// arbre vide -> créer racine
				this.racine = 0;
				Bloc blocRacine = new Bloc(0, -1, stagAAjouter, -1, -1, -1);
				blocRacine.ecrireBloc(raf);			//   ???  Peut-on et faut-il effacer le fichier ???
				//System.out.println("Ajout de la racine");	// pour debug
				return true;
			}
			else {
				Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);		// MaJ des enfants de la racine (dommage de le faire à chaque fois, peut-on trouver mieux ?)
				int indexNouveauBloc = (int)raf.length()/ConstantesDAppli.TAILLE_BLOC;  	// détermination de l'index
				Bloc blocAAjouter = new Bloc(indexNouveauBloc, -1, stagAAjouter, -1, -1, -1);
				//System.out.println("Ajout du bloc "+stagAAjouter.getNom()+" à l'index "+indexNouveauBloc);
				//return blocRacine.ajouterBloc(blocAAjouter, raf);									// on demande au bloc racine de placer le nouveau bloc
					// pour debug
				boolean test = blocRacine.ajouterBloc(blocAAjouter, raf);
				//System.out.println(test);
				return test;
			}
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// Crée un ABR sous forme de fichier binaire à partir des infos du fichier .txt
	public void creerFichierBinDepuisFichierTxt(RandomAccessFile annuaireBin) {
		File annuaireTxt = new File(ConstantesDAppli.getNomFichierTxt());		// fichier à lire
		try {
			FileReader fr = new FileReader(annuaireTxt);
			BufferedReader br = new BufferedReader(fr);
			
			while(br.ready()) {
				String nom = br.readLine().toUpperCase();				// lecture des attributs du Stagiaire
				String prenom = br.readLine();
				String dep = br.readLine();
				String promo = br.readLine();
				int anneeF = Integer.parseInt(br.readLine());
				br.readLine();											// pour passer la ligne *
				
				Stagiaire nouveauStagiaire = new Stagiaire(nom, prenom, dep, promo, anneeF);    // crée le nouveau stagiaire
				this.ajouterStagiaire(nouveauStagiaire, annuaireBin);	// ajout du nouveau stagiaire à l'ABR
			}
			br.close();
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste dans l'ordre alphabétique
	public List<Stagiaire> listeGND(RandomAccessFile raf) {
		if (this.racine==-1) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf); 
			return blocRacine.listeGND(raf, racine, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de nom égal à 'nom'
	public List<Stagiaire> rechercheNom(String nom, RandomAccessFile raf) {
		if (this.racine==-1) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
			return blocRacine.rechercheNom(nom.toUpperCase(), raf, racine, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de nom commençant par 'nom'
	public List<Stagiaire> rechercheNomPartiel(String nom, RandomAccessFile raf) {
		if (this.racine==-1) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
			return blocRacine.rechercheNomPartiel(nom.toUpperCase(), raf, racine, new ArrayList<>());
		}
	}

	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de prénom égal à (ou commençant par) 'prenom'
	public List<Stagiaire> recherchePrenom(String prenom, RandomAccessFile raf, boolean partiel) {
		if (this.racine==-1) {
			return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
		}
		else {
			Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
			return blocRacine.recherchePrenom(Outils.prenomNormalise(prenom), raf, racine, new ArrayList<>(), partiel);
		}
	}
	
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de département égal à 'dep'
			public List<Stagiaire> rechercheDep(String dep, RandomAccessFile raf) {
				if (this.racine==-1) {
					return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
				}
				else {
					Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
					return blocRacine.rechercheDep(dep,raf, racine, new ArrayList<>());
				}
			}
	
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires de promo égal à (ou commençant par) 'promo'
		public List<Stagiaire> recherchePromo(String promo, RandomAccessFile raf) {
			if (this.racine==-1) {
				return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
			}
			else {
				Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
				return blocRacine.recherchePromo(promo,raf, racine, new ArrayList<>());
			}
		}
		
	// Lance la lecture du fichier .bin en parcours GND pour créer une liste des stagiaires d'année égale à 'annee'
		public List<Stagiaire> rechercheAnnee(int annee, RandomAccessFile raf) {
			if (this.racine==-1) {
				return new ArrayList<>();  // ou null ? La liste vide permet d'utiliser un 'for each'
			}
			else {
					Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
					return blocRacine.rechercheAnnee(annee,raf, racine, new ArrayList<>());
				}
			}	
		
	//Lance une recherche multicritère
		public List<Stagiaire> recherche(StagiaireARechercher stagiaire, RandomAccessFile raf) {
			List<Stagiaire> res = new ArrayList<>();
			boolean premiereRecherche = true;
			//recherche nom = prioritaire
			if (!(stagiaire.getNom().equals(""))) {
				if (stagiaire.isNomPartiel()) {
					res = this.rechercheNomPartiel(stagiaire.getNom().toUpperCase(), raf);		
				} else {
					res = this.rechercheNom(stagiaire.getNom().toUpperCase(), raf);
				}
			premiereRecherche = false;
			} 
			//ensuite recherche prénom - si vide on passe au prochain critère
			//on change de méthode de recherche en fonction du boolean premiereRecherche (dans l'arbre si true, dans une liste si false)
			if (!(stagiaire.getPrenom().equals(""))) {
				String prenomATester = Outils.prenomNormalise(stagiaire.getPrenom());
				if (premiereRecherche){
					res = this.recherchePrenom(prenomATester, raf, stagiaire.isPrenomPartiel());
					premiereRecherche = false;
				} else {
					res = Outils.recherchePrenomDansListe(res, prenomATester,stagiaire.isPrenomPartiel());
				}
			}
			//recherche département - si vide on passe au prochain critère
			if (!(stagiaire.getDep().equals(""))) {
				if (premiereRecherche){
					res = this.rechercheDep(stagiaire.getDep(), raf);
					premiereRecherche = false;
				} else {
					res = Outils.rechercheDepDansListe(res, stagiaire.getDep());
				}
			}
			//recherche promo - si vide on passe au prochain critère
			if (!(stagiaire.getPromo().equals(""))) {
				if (premiereRecherche){
					res = this.recherchePromo(stagiaire.getPromo().toUpperCase(), raf);
					premiereRecherche = false;
				} else {
					res = Outils.recherchePromoDansListe(res, stagiaire.getPromo());
				}
			}
			
			//recherche annee - dernier critère
			if (stagiaire.getAnneeF()>0) {
				if (premiereRecherche){
					res = this.rechercheAnnee(stagiaire.getAnneeF(), raf);
				} else {
					res = Outils.rechercheAnneeDansListe(res, stagiaire.getAnneeF());
				}
			}
		
			return res;
		}
		
	// Recherche un bloc dans l'ABR (pour suppression)
	public Bloc rechercheBloc(Stagiaire stagASupprimer,RandomAccessFile raf) {
		if (this.racine==-1) {
			return null;
		}
		else {
			Bloc blocRacine=Bloc.lireBlocAIndex(racine, raf);
			return blocRacine.rechercheBloc(stagASupprimer, raf);
		}
	}	
		
	// Suppresssion du stagiaire 'stagASupprimer' dans l'ABR. Retourne 'false' si le stagiaire n'est pas dans l'annuaire
	public boolean supprimer(Stagiaire stagASupprimer, RandomAccessFile raf) {
//		Stagiaire jerome = new Stagiaire ("POTIN", "Thomas", "75", "ATOD 21", 2014);
//		Bloc bloc1 = new Bloc(0, -1, jerome, -1, -1, -1);
//		System.out.println("bloc à desindexer : "+bloc1.lireBlocAIndex(0, raf));
		Bloc blocADesindexe = rechercheBloc(stagASupprimer, raf);
//		System.out.println("bloc à desindexer : "+blocADesindexe);
		if (blocADesindexe==null) {
			return false;
		}
		else {
			int index = blocADesindexe.getIndex();    // infos concernant le bloc du stagiaire à supprimer
			int pere = blocADesindexe.getPere();
			int filsG = blocADesindexe.getFilsG();
			int filsD = blocADesindexe.getFilsD();
			int indexDoublon = blocADesindexe.getIndexDoublon();
			
			if (filsG==-1 && filsD==-1 && indexDoublon ==-1) {// Cas 1 : feuille ou cellule terminale d'une liste de doublons
				
				if (pere == -1) {
					this.racine = -1;
				}
				else {
					Bloc blocPere = Bloc.lireBlocAIndex(pere, raf);
					//System.out.println("Je suis dans le 1er IF");
					//Cas 1bis : Feuille arbre : on regarde où on est par rapport au père, afin de remplacer index FG ou FD
					if (blocPere.getFilsG()==index) {
	//					System.out.println("Je suis FG");
						blocPere.ecrireFilsG(-1, raf);
					} 
					else if (blocPere.getFilsD()==index) {
	//					System.out.println("Je suis FD");
						blocPere.ecrireFilsD(-1, raf);
					} 
					else {
	//				System.out.println("je suis dans le if 1");
	//				System.out.println("Père : "+blocADesindexe.lireBlocAIndex(pere, raf));
						Bloc.lireBlocAIndex(pere, raf).ecrireIndexDoublon(-1, raf);
	//				System.out.println("Père : "+blocADesindexe.lireBlocAIndex(pere, raf));
					}
				}
			}
			else if (indexDoublon!=-1) {						// Cas 2 : j'ai un suivant dans la liste des doublons
				System.out.println("J'ai un homonyme");
				Bloc blocSuivant = Bloc.lireBlocAIndex(indexDoublon, raf);
				blocSuivant.ecrirePere(pere,raf);
				System.out.println("père : "+pere);
				System.out.println("Bloc remplacant avec pere maj : "+blocSuivant);
				if (filsG!=-1) {							
					blocSuivant.ecrireFilsG(filsG, raf);
					Bloc.lireBlocAIndex(filsG, raf).ecrirePere(indexDoublon,raf);
				}
				if (filsD!=-1) {
					blocSuivant.ecrireFilsD(filsD, raf);
					Bloc.lireBlocAIndex(filsD, raf).ecrirePere(indexDoublon,raf);
				}
				if (pere==-1) {  //cas racine
					System.out.println("je suis la racine");
					this.racine = indexDoublon;
				}
				else { 	// j'ai un suivant mais je ne suis pas la racine : màj du père
					Bloc blocPere = Bloc.lireBlocAIndex(pere, raf);
					if (blocPere.getFilsG()==index) {
						blocPere.ecrireFilsG(indexDoublon, raf);
					}
					else if (blocPere.getFilsD()==index) {
						blocPere.ecrireFilsD(indexDoublon, raf);
					}
					else {
						blocPere.ecrireIndexDoublon(indexDoublon, raf);
					}
				}
			}
			else if (filsG == -1 || filsD == -1) {//Cas 3 : d'un noeud qui a un fils et pas de doublon
				System.out.println("Cas 3");
				int fils = filsG;
				if (filsG == -1) {		//rechercher le fils
					fils = filsD;
				}
				if (pere == -1) { 		//cas racine avec un fils
					this.racine = fils;
					Bloc.lireBlocAIndex(fils,raf).ecrirePere(-1, raf);
				}	
				else {
					Bloc.lireBlocAIndex(fils, raf).ecrirePere(pere, raf);
					Bloc blocPere = Bloc.lireBlocAIndex(pere, raf);			
						if (blocPere.getFilsG()==index) { 		
							blocPere.ecrireFilsG(fils,raf);  
						}
						else {
							blocPere.ecrireFilsD(fils,raf); 
						}
				}
			}
			else { //Cas 4 : deux fils et pas de doublon
				System.out.println("Cas 4");
				int minDesMax = filsD;
				while(Bloc.lireBlocAIndex(minDesMax, raf).getFilsG() != -1) {		// recherche du plus petit majorant
					minDesMax = Bloc.lireBlocAIndex(minDesMax, raf).getFilsG();
				}
				Bloc blocADeplacer = Bloc.lireBlocAIndex(minDesMax, raf);
				System.out.println("Bloc à déplacer : "+blocADeplacer);
				// Maj des enfants du bloc à déplacer : 
				// 1. mon filsG devient son filsG
				blocADeplacer.ecrireFilsG(filsG, raf);
				Bloc.lireBlocAIndex(filsG, raf).ecrirePere(minDesMax, raf);
				if (minDesMax!=filsD) {
					// 2. son filsD devient le filsG de son père
					if (blocADeplacer.getFilsD()==-1) {
						Bloc.lireBlocAIndex(blocADeplacer.getPere(), raf).ecrireFilsG(-1, raf);
					}
					else {
						Bloc.lireBlocAIndex(blocADeplacer.getPere(), raf).ecrireFilsG(blocADeplacer.getFilsD(), raf);
						Bloc.lireBlocAIndex(blocADeplacer.getFilsD(), raf).ecrirePere(blocADeplacer.getPere(), raf);
					}
						// 3. mon filsD devient son filsD
					blocADeplacer.ecrireFilsD(filsD, raf);
					Bloc.lireBlocAIndex(filsD, raf).ecrirePere(minDesMax, raf);
				}
				// Maj du parent du bloc à déplacer
				if (pere==-1) {
					this.racine=minDesMax;
					blocADeplacer.ecrirePere(-1, raf);
				}
				else {
					blocADeplacer.ecrirePere(blocADesindexe.getPere(), raf);     // MaJ du père de blocADeplacer
					Bloc blocPere = Bloc.lireBlocAIndex(pere, raf);
					if (blocPere.getFilsG()==index) { 		
						blocPere.ecrireFilsG(minDesMax,raf);  
					}
					else {
						blocPere.ecrireFilsD(minDesMax,raf); 
					}
				}
			}
			System.out.println(this);
			return true;
		}
	}	

	// Modifie un stagiaire de façon brutale : ajoute 'nouveauStag' puis, si l'ajout s'est bien passé, supprime 'ancienStag'
	public boolean modifier(Stagiaire ancienStag, Stagiaire nouveauStag, RandomAccessFile raf) {
		boolean res = ajouterStagiaire(nouveauStag, raf);
		if (res) {
			supprimer(ancienStag, raf);
		}
		return res;
	}

	// Modifie un stagiaire : si même nom, modifie les infos du bloc concerné, sinon ajoute puis supprime
	public boolean modifier2(Stagiaire ancienStag, Stagiaire nouveauStag, RandomAccessFile raf) {
		boolean res = true;
		if (ancienStag.getNom().equals(nouveauStag.getNom())) {		// le nom de nouveauStag est déjà présent dans l'annuaire : il suffit de modifier les infos du bloc dans le fichier .bin
			if (recherche(new StagiaireARechercher(nouveauStag,false,false), raf).size()==1) {  // si 'nouveauStag' est déjà dans l'annuaire
				System.out.println("nouveauStag déjà dans la base");
				res = false;																		// pas d'ajout et retourne 'false'
			}
			else {														//  si 'nouveauStag' n'est pas déjà dans l'annuaire
				System.out.println("nom présent, stagARechercher absent");
				Bloc blocAncienStag = rechercheBloc(ancienStag, raf);		// on recherche le bloc de 'ancienStag'
				blocAncienStag.setCle(nouveauStag);							// on met à jour les infos du stagiaire
				blocAncienStag.ecrireBloc(raf);
			}
		}
		else {														// le nom de 'nouveauStag' est absent de l'annuaire : on crée nouveauStag et on supprime ancienStag
			res = ajouterStagiaire(nouveauStag, raf);					// ajout ; si 'nouveauStag' deja dans l'annuaire, pas d'ajout et retourne 'false'
			if (res) {													// si l'ajout a été effectué
			supprimer(ancienStag, raf);										// suppression de 'ancienStag'
			System.out.println("résultat de ajout() : "+res);
			}
		}
		return res;
	}

	
	@Override
	public String toString() {
		if (this.racine==-1) {
			return "Arbre vide";
		} else {
		return "Arbre de racine : "+racine;
		}
	}

	
	// ********** Getters et Setters ***********
	public int getRacine() {
		return racine;
	}

	public void setRacine(int racine) {
		this.racine = racine;
	}
	
}
