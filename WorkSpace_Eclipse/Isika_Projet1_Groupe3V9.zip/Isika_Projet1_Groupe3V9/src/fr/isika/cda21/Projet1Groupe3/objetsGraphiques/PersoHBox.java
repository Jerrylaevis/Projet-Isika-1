package fr.isika.cda21.Projet1Groupe3.objetsGraphiques;

import javafx.geometry.Insets;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

public class PersoHBox extends HBox {

	public PersoHBox(){
		super();
		this.setPadding(new Insets(20,0,0,0));	
	}
	
}